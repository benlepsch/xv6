#ifndef KALLOC_H
#define KALLOC_H

int isphysicalpagefree(int);

#endif